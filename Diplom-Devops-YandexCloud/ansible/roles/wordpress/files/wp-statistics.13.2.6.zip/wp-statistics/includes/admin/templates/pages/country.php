<div class="postbox-container" id="wps-big-postbox">
    <div class="metabox-holder">
        <div class="meta-box-sortables" id="<?php echo \WP_STATISTICS\Meta_Box::getMetaBoxKey('countries'); ?>">
            <div class="postbox">
                <div class="inside">
                    <!-- DO Js -->
                </div>
            </div>
        </div>
    </div>
</div>